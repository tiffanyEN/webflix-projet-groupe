<?php

namespace App\Repository;

use App\Entity\EmailMembre;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method EmailMembre|null find($id, $lockMode = null, $lockVersion = null)
 * @method EmailMembre|null findOneBy(array $criteria, array $orderBy = null)
 * @method EmailMembre[]    findAll()
 * @method EmailMembre[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class EmailMembreRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, EmailMembre::class);
    }

    // /**
    //  * @return EmailMembre[] Returns an array of EmailMembre objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('e')
            ->andWhere('e.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('e.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?EmailMembre
    {
        return $this->createQueryBuilder('e')
            ->andWhere('e.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
